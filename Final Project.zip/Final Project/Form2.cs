﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            Form zip = new Form();
            zip.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sourcefolder = textBox1.Text;
            string searchWord = txtfile.Text;
            List<string> allFiles = new List<string>();
            AddFileNamesToList(sourcefolder, allFiles);
            foreach (string filename in allFiles)
            {
                string contents = File.ReadAllText(filename);
                if (contents.Contains(searchWord))
                {
                    listBox2.Items.Add(filename);

                }
            }


        }
        public static void AddFileNamesToList(string sourcedir, List<string> allFiles)
        {

            string[] fileEntries = Directory.GetFiles(sourcedir);
            foreach (string filename in fileEntries)
            {
                allFiles.Add(filename);
            }

            //Recursion    
            string[] subdirectoryEntries = Directory.GetDirectories(sourcedir);
            foreach (string item in subdirectoryEntries)
            {
                // Avoid "reparse points"
                if ((File.GetAttributes(item) & FileAttributes.ReparsePoint) != FileAttributes.ReparsePoint)
                {
                    AddFileNamesToList(item, allFiles);
                }
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBS = new FolderBrowserDialog();
            if (FBS.ShowDialog() == DialogResult.OK)
            {
                string[] dirs = Directory.GetDirectories(FBS.SelectedPath);

                foreach (string dir in dirs)
                {
                    textBox1.Text = dir;
                  
                }
            }
        }
       

        private void button4_Click(object sender, EventArgs e)
        {
            web f = new web();
            f.Show();
            this.Close();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }
    }
}




